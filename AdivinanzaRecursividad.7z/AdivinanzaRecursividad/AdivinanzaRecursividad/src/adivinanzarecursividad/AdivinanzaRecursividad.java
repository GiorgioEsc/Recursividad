
package adivinanzarecursividad;

import java.util.Scanner;

public class AdivinanzaRecursividad {
public static Scanner entrada = new Scanner (System.in);
    public static void main(String[] args) 
    {
        adivinanza( 0 , 100 );
    }
    
    public static void adivinanza( int min , int max )
    {
       
        if(min==max)
        {
            System.out.println("tramposo porque es "+max);
        }
        else{
            System.out.println( "es " + ( (min+max)/2 ) +"?" );
            String simbolo = entrada.nextLine();
            switch(simbolo){
                case "+":
                    min = ( (min+max)/2 );
                    adivinanza( min , max );
                    break;
                case "-":
                    max = ( (min+max)/2 );
                    adivinanza( min , max );
                    break;
                case "=":
                    System.out.println("yuju "+( (min+max)/2 )+"!");
                    break;
            }
        }
    }
   
}
